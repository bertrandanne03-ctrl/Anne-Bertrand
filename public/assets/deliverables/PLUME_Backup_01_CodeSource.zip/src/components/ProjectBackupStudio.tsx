import { useState } from 'react';
import { Archive, Check, Code2, Download, FolderArchive, Loader2 } from 'lucide-react';
import { fetchAndDownloadProjectZip, ProjectExportScope } from '../utils/deliverableDownload';
import { CopyButton } from './CopyButton';

const RESUME_CONVERSATION_PROMPT = `Tu travailles sur l'application Plume Digital Shop / PLUME STYLE (React 19 + Vite + Tailwind CSS + Express dans server.ts sur port 3000).
Avant toute modification, lis src/components/TumblerWrapStudio.tsx et liste public/assets/deliverables/.
Règles strictes :
- Réponds toujours en français ; rédige tous les textes/titres/tags Etsy, Pinterest et TikTok en anglais avec 0 marque déposée.
- Ne prétends jamais avoir testé physiquement une presse à chaud.
- Tous les téléchargements dans l'aperçu doivent passer par /api/deliverables/:filename et fetchAndDownloadDeliverable().`;

export function ProjectBackupStudio() {
  const [downloadingScope, setDownloadingScope] = useState<ProjectExportScope | null>(null);
  const [downloadedScope, setDownloadedScope] = useState<ProjectExportScope | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleExport = async (scope: ProjectExportScope) => {
    setError(null);
    setDownloadingScope(scope);
    try {
      await fetchAndDownloadProjectZip(scope);
      setDownloadedScope(scope);
      window.setTimeout(() => {
        setDownloadedScope((curr) => (curr === scope ? null : curr));
      }, 3000);
    } catch (err: unknown) {
      setError(
        err instanceof Error ? err.message : 'Erreur lors de la création de l’archive ZIP.'
      );
    } finally {
      setDownloadingScope(null);
    }
  };

  const packs: {
    scope: ProjectExportScope;
    title: string;
    subtitle: string;
    sizeLabel: string;
    buttonLabel: string;
    accentClass: string;
    icon: 'code' | 'folder' | 'archive';
  }[] = [
    {
      scope: 'code',
      title: '1. Code Source Complet + Guide de Reprise (.zip)',
      subtitle:
        'Contient tout src/, server.ts, package.json, la configuration et README_EXPORT_ET_PROMPT_REPRISE.txt pour ouvrir dans VS Code, Cursor, Replit ou une autre IA.',
      sizeLabel: '< 1 Mo · Téléchargement immédiat',
      buttonLabel: 'Télécharger le Code (.zip)',
      accentClass: 'bg-[#1B3B5A] hover:bg-[#122940] text-[#FAF6F0]',
      icon: 'code',
    },
    {
      scope: 'skilodge',
      title: '2. Collection 2 · Ski Lodge Complète (.zip)',
      subtitle:
        'Tous tes fichiers Ski Lodge : Tumbler 20 oz (Straight/Tapered + PDF), Seamless 3600×3600, Camping Mug 2550×975, Slides Etsy et les 3 Épingles Pinterest 1000×1500.',
      sizeLabel: '~119 Mo · Prêt pour Etsy & Google Drive',
      buttonLabel: 'Télécharger Ski Lodge (.zip)',
      accentClass: 'bg-[#7A1621] hover:bg-[#5E1019] text-[#FAF6F0]',
      icon: 'folder',
    },
    {
      scope: 'heritage',
      title: '3. Collection 1 · Heritage Christmas + Playbook (.zip)',
      subtitle:
        'Tous les motifs Heritage Christmas, PDF, mockups et le Playbook Stratégie Etsy (.docx) pour ne rien laisser derrière.',
      sizeLabel: '~172 Mo · Sauvegarde Collection 1',
      buttonLabel: 'Télécharger Heritage & Playbook (.zip)',
      accentClass: 'bg-[#2C2520] hover:bg-[#1C1917] text-[#FAF6F0]',
      icon: 'archive',
    },
    {
      scope: 'deliverables',
      title: '4. Pack Intégral de Tous les Livrables (.zip)',
      subtitle:
        'Regroupe en une seule archive tout le dossier public/assets/deliverables/ (Collections 1 + 2 + Pins + Playbook). Recommandé sur Wi-Fi stable.',
      sizeLabel: '~291 Mo · Archive complète livrables',
      buttonLabel: 'Tout Télécharger (Livrables .zip)',
      accentClass: 'bg-[#44403C] hover:bg-[#1C1917] text-[#FAF6F0]',
      icon: 'archive',
    },
  ];

  return (
    <section className="max-w-4xl mx-auto space-y-6">
      <div className="bg-[#F6F2EC] border border-[#E5DDD0] p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 border-b border-[#E5DDD0] pb-4">
          <div>
            <p className="text-xs uppercase tracking-widest text-[#7A1621] font-medium">
              Sauvegarde Directe · Indépendante d’AI Studio
            </p>
            <h2 className="font-serif text-2xl font-medium text-[#1C1917]">
              Exporter l’Application &amp; Tous Tes Fichiers (.zip)
            </h2>
          </div>
          <span className="font-mono text-[11px] text-[#57534E]">
            Export local instantané
          </span>
        </div>

        <p className="text-xs text-[#57534E] leading-relaxed">
          Si le bouton de téléchargement de la plateforme ne fonctionne pas, utilise ces boutons
          intégrés directement à ton serveur : ils génèrent de vraies archives <strong>.zip</strong>{' '}
          valides sur ton appareil pour continuer sur{' '}
          <strong>VS Code, Cursor, Replit, Google Drive</strong> ou dans une autre discussion.
        </p>

        {error && (
          <div
            role="alert"
            className="p-3.5 bg-[#FAF6F0] border border-[#7A1621]/40 text-xs text-[#7A1621]"
          >
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {packs.map((pack) => {
            const isBusy = downloadingScope === pack.scope;
            const isDone = downloadedScope === pack.scope;
            const Icon =
              pack.icon === 'code'
                ? Code2
                : pack.icon === 'folder'
                  ? FolderArchive
                  : Archive;

            return (
              <div
                key={pack.scope}
                className="bg-[#FAF6F0] border border-[#D6CEBE] p-4 flex flex-col justify-between gap-4"
              >
                <div className="space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-sm font-medium text-[#1C1917] leading-snug">
                      {pack.title}
                    </h3>
                    <Icon className="w-4 h-4 text-[#78716C] shrink-0 mt-0.5" aria-hidden="true" />
                  </div>
                  <p className="text-[11px] text-[#57534E] leading-relaxed">{pack.subtitle}</p>
                  <p className="font-mono text-[10px] text-[#78716C]">{pack.sizeLabel}</p>
                </div>

                <button
                  type="button"
                  disabled={downloadingScope !== null}
                  onClick={() => handleExport(pack.scope)}
                  className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium transition-colors cursor-pointer disabled:opacity-60 ${pack.accentClass}`}
                >
                  {isBusy ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                  ) : isDone ? (
                    <Check className="w-3.5 h-3.5" aria-hidden="true" />
                  ) : (
                    <Download className="w-3.5 h-3.5" aria-hidden="true" />
                  )}
                  <span>
                    {isBusy
                      ? 'Création du ZIP...'
                      : isDone
                        ? 'ZIP téléchargé !'
                        : pack.buttonLabel}
                  </span>
                </button>
              </div>
            );
          })}
        </div>

        {/* Ready-to-copy Resume Prompt for new chat / other AI platform */}
        <div className="pt-4 border-t border-[#D6CEBE] space-y-2.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <p className="text-[11px] uppercase tracking-widest text-[#1B3B5A] font-medium">
                Continuer dans une autre discussion ou avec une autre IA
              </p>
              <p className="text-[11px] text-[#57534E]">
                Colle ce message au tout début de la nouvelle conversation pour transférer toutes tes
                règles en 2 secondes :
              </p>
            </div>
            <CopyButton
              text={RESUME_CONVERSATION_PROMPT}
              label="Copier Prompt de Reprise"
              copiedLabel="Prompt Copié"
              variant="primary"
            />
          </div>
          <pre className="text-[11px] text-[#2C2520] whitespace-pre-wrap font-sans leading-relaxed bg-[#FAF6F0] p-3.5 border border-[#E5DDD0] select-all">
            {RESUME_CONVERSATION_PROMPT}
          </pre>
        </div>
      </div>
    </section>
  );
}
