PLUME DIGITAL SHOP / PLUME STYLE — GUIDE DE REPRISE & INSTALLATION
======================================================================

1. LANCER EN LOCAL (PC / Mac / Cursor / VS Code / Replit) :
   - Prerequis : Node.js 20+
   - Dans ce dossier, executez :
       npm install
       npm run dev
   - Ouvrez http://localhost:3000 dans votre navigateur.
   - Note : Tous les outils Tumbler Wrap, Mug Emaille, Seamless et le Kit Marketing fonctionnent sans cle API.
   - Optionnel (uniquement pour l'onglet 5-Block Lookbook Factory IA) : creez un fichier .env avec GEMINI_API_KEY=votre_cle

2. PROMPT DE REPRISE (A COLLER DANS UNE NOUVELLE DISCUSSION IA) :
   Tu travailles sur l'application Plume Digital Shop / PLUME STYLE (React 19 + Vite + Tailwind + Express dans server.ts sur port 3000). Avant toute modification, lis src/components/TumblerWrapStudio.tsx et liste public/assets/deliverables/. Regles strictes : reponds en francais ; redige tous les textes/titres/tags Etsy, Pinterest et TikTok en anglais avec 0 marque deposee ; ne pretends jamais avoir teste physiquement une presse a chaud ; garde tous les telechargements via /api/deliverables/:filename.
